def hide_traj_controls():
    viewer.traj_controls.hide()
    
def show_traj_controls():
    viewer.traj_controls.show()