import os
from .local import LocalDB
from .cirdb import CirDB
from .chemlabdb import ChemlabDB
from .chemspiderdb import ChemSpiderDB
from .rcsbdb import RcsbDB