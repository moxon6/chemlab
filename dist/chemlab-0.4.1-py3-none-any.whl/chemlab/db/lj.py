
k_boltzmann = 1.3806503e-23
typetolj ={
    "Ar" : (125.7*k_boltzmann, 0.3345e-9),
}