from ._xdrfile import XDRError, XTCReader

__all__ = ['XDRError', 'XTCReader']
