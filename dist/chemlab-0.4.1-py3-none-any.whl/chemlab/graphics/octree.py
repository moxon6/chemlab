"""Python implementation of an octree, this is useful for ray picking
"""


class Octree(object):
    pass
    
# o = Octree(r_array)
# o.ray_intersection(origin, direction)
# This thing has to return a list with a list of the intersected nodes.
# Or it can return already the points contained in the nodes.

