'''Test the propagation of the equation of motion'''

